package com.example.ednanotebook.db

class ListItem {

    var title = "empty"
    var desc = "empty"
    var uri = "empty"




}