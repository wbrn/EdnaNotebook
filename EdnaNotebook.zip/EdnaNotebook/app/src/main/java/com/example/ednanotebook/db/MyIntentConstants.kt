package com.example.ednanotebook.db

object MyIntentConstants {

    const val  I_TITLE_KEY = "title_key"
    const val  I_DESC_KEY = "desc_key"
    const val  I_URI_KEY = "uri_key"
}